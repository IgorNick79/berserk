from pathlib import Path
import hashlib,json
root=Path(__file__).parent/'app'
changes={
'src/Core/TurnProcessor.php': [('        $this->applyStartEffects();','        if (function_exists("stage3_probe")) \\stage3_probe($this->state, "initial-before-start-effects");\n        $this->applyStartEffects();\n        if (function_exists("stage3_probe")) \\stage3_probe($this->state, "after-start-effects");')],
'src/Core/Engine.php': [('        GameLog::append($state, $playerKey, $cmd, $result);','        if (function_exists("stage3_probe")) \\stage3_probe($state, "engine-return:".$cmd->type);\n        GameLog::append($state, $playerKey, $cmd, $result);')],
'src/Core/ValhallaProcessor.php': [('        $remaining = max(1, (int) ($pv[\'remaining\'] ?? $pv[\'repeat\'] ?? 1)) - 1;','        if (function_exists("stage3_probe")) \\stage3_probe($this->state, "valhalla-after-application");\n        $remaining = max(1, (int) ($pv[\'remaining\'] ?? $pv[\'repeat\'] ?? 1)) - 1;')],
'src/Core/StrikeResolver.php': [('        if ($this->openAfterStrikeExecute($strike)) {','        if (function_exists("stage3_probe")) \\stage3_probe($this->state, "after-local-combat-before-followup");\n        if ($this->openAfterStrikeExecute($strike)) {')]
}
manifest=[]
for file,replacements in changes.items():
 p=root/file; before=p.read_bytes(); s=before.decode('utf-8')
 for needle,new in replacements:
  count=s.count(needle)
  if count<1: raise RuntimeError(file+' missing marker')
  s=s.replace(needle,new)
 p.write_text(s,encoding='utf-8',newline='')
 manifest.append({'file':file,'before_sha256':hashlib.sha256(before).hexdigest(),'after_sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(root.parent/'results/instrumentation.json').write_text(json.dumps(manifest,indent=2))
