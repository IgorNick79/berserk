<?php
declare(strict_types=1);
$root=realpath(__DIR__.'/..');
if(getenv('STAGE3_ISOLATED')!=='YES'||!str_contains(str_replace('\\','/',$root),'/stage3-verification/app'))throw new RuntimeException('Isolated copy only');
$cfg=require $root.'/config/db.php';if($cfg['host']!=='127.0.0.1:33387'||$cfg['name']!=='berserk_stage3')throw new RuntimeException('Wrong DB');
require $root.'/src/Core/Autoloader.php';
use Berserk\Core\{Autoloader,Db,GameRepository,CommandJournalRepository,GameState,CardInstance,Engine,Command,StaleStateException};
Autoloader::register();Autoloader::addNamespace('Berserk\\',$root.'/src/');$db=new Db($cfg);$repo=new GameRepository($db);$j=new CommandJournalRepository($db);
$dir=$root.'/../results';
if(($argv[1]??'')==='worker'){
 [$file,$mode,$game,$actor,$version,$barrier]=$argv;$s=$repo->findById((int)$game);$type=$actor==='host'?'move':'resign';$payload=$actor==='host'?['card_id'=>1,'row'=>2,'col'=>3]:[];
 $row=$j->registerProcessing((int)$game,$actor,'stage3_race_'.$game.'_'.$actor,$type,$payload,(int)$version);file_put_contents($barrier.'.'.$actor,'ready');$until=microtime(true)+15;while(!is_file($barrier.'.go')){if(microtime(true)>$until)throw new RuntimeException('barrier timeout');usleep(1000);}
 try{$repo->executeLockedCommand($s,$j,(int)$row['id'],fn($w)=>(new Engine())->apply($w,$actor,new Command($type,$payload)));}catch(StaleStateException){$fresh=$repo->findById((int)$game);$j->markConflict((int)$row['id'],$fresh->persistenceVersion,'stale_state');}
 echo $j->findById((int)$row['id'])['status'];exit;
}
$all=[];
for($round=1;$round<=3;$round++){
 $s=$repo->create(990001,990002);$s->status='battle';$s->battle=['turn'=>1,'active'=>'host','strike'=>null,'hidden_row_revealed'=>true];foreach([[1,'host',3,3],[2,'player',5,3]] as [$id,$owner,$r,$c])$s->addCard(new CardInstance(instanceId:$id,ukid:'synthetic',owner:$owner,zone:'field',row:$r,col:$c,hp:20,hpMax:20,move:2,moveMax:2));$repo->save($s);$v=$s->persistenceVersion;$barrier=$dir.'/race_'.$s->gameId;$children=[];
 foreach(['host','player']as $actor){$pipes=[];$proc=proc_open([PHP_BINARY,'-c',$root.'/../php.ini',__FILE__,'worker',(string)$s->gameId,$actor,(string)$v,$barrier],[0=>['pipe','r'],1=>['pipe','w'],2=>['pipe','w']],$pipes,$root);if(!is_resource($proc))throw new RuntimeException('spawn failed');fclose($pipes[0]);$children[]=[$proc,$pipes];}
 $until=microtime(true)+15;while(!is_file($barrier.'.host')||!is_file($barrier.'.player')){if(microtime(true)>$until)throw new RuntimeException('readiness timeout');usleep(1000);}file_put_contents($barrier.'.go','go');$outputs=[];foreach($children as[$proc,$pipes]){$stdout=stream_get_contents($pipes[1]);$stderr=stream_get_contents($pipes[2]);fclose($pipes[1]);fclose($pipes[2]);$exit=proc_close($proc);$outputs[]=compact('stdout','stderr','exit');if($exit!==0)throw new RuntimeException('worker failed '.$stderr);}
 $rows=$db->fetchAll('SELECT player_key,status,before_version,after_version FROM battle_command_journal WHERE game_id='.$s->gameId.' ORDER BY id');$statuses=array_column($rows,'status');sort($statuses);$fresh=$repo->findById($s->gameId);if($statuses!==['committed','conflict']||$fresh->persistenceVersion!==$v+1)throw new RuntimeException('Race invariants failed');$all[]=['round'=>$round,'game'=>$s->gameId,'rows'=>$rows,'version_before'=>$v,'version_after'=>$fresh->persistenceVersion,'state'=>$fresh->toArray(),'processes'=>$outputs];
}
file_put_contents($dir.'/race-results.json',json_encode($all,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));echo "PASS 3 rounds, two participant processes, one committed and one conflict per round\n";
