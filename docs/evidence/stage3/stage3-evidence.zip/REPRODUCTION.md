# Stage 3 diagnostic reproduction

Baseline: 6be7d6875b7ac99c98b88b29061b0eba4dc6ee03. This archive is evidence and test-only scripts, not a runtime feature.

Use a NEW disposable `C:/Users/mi/Documents/Berserk/stage3-verification` directory (the original run is retained there; do not overwrite it). Copy src, tools, templates, www, docs from the baseline to app. Do NOT copy config, storage, tmp, .git, sessions or any real matches. Create empty app/config, app/storage, data, results, sessions. Extract the two diagnostic tools to app/tools.

PHP used: C:/OSPanel/modules/php/PHP_8.1/php.exe (8.1.9); MariaDB: C:/OSPanel/modules/database/MariaDB-10.8-Win10/bin (10.8.4). Install a new datadir with mysql_install_db.exe --datadir=<lab>/data --port=33387 --password=stage3_local_only. This password is generated test-only, not any existing account credential. Do not install a Windows service.

Start mysqld.exe --no-defaults --datadir=<lab>/data --port=33387 --bind-address=127.0.0.1 --innodb-flush-log-at-trx-commit=1 --log-error=<lab>/results/mariadb.log in a hidden process. Refuse an occupied port; do not connect to an existing server as a substitute. Execute setup.sql and fixture-schema.sql ONLY after SELECT @@datadir,@@port proves the new lab server identity. Setup uses only synthetic accounts/cards; no production export.

app/config/db.php must return ['host'=>'127.0.0.1:33387','user'=>'stage3','pass'=>'stage3_test_only','name'=>'berserk_stage3']. Stage3 tools additionally check the isolated path/config/server identity. PHP ini: extension_dir points to PHP_8.1/ext; load mysqli and mbstring; session.save_path=<lab>/sessions; error_log=<lab>/results/php-errors.log; log_errors=1. Set PHPRC to that test php.ini for endpoint subprocesses. No source config is read.

Run the 13 suites listed in summary.json with this PHP/ini, from app, one process per suite. Copy docs/cards is required for Bon/Berrow and Swamp children. Synthetic cards and elements tables from fixture-schema.sql are required by the command endpoint suite. A missing config/card table causing SKIP is not a PASS.

Diagnostic probes: run prepare_trace.py exactly once against an unmodified isolated app; its replacements are guarded function calls, no new engine control. Enable probe.php through PHP `-d auto_prepend_file=<lab>/probe.php`; set STAGE3_TRACE to an absolute path below <lab>/results. It observes toArray copies only. The 4 modified copy files and before/after hashes are in results/instrumentation.json. Original checkout files must match source-hashes.json. Do not copy instrumented sources to the checkout.

Set STAGE3_ISOLATED=YES. Run app/tools/stage3_scenarios.php with probe.php enabled (I1 and K5 require internal observation points). Run app/tools/stage3_race.php with test ini; it spawns two bounded PHP workers per round and verifies journal/version invariants. No additional COMMIT is inserted by observations. Race workers have a 15-second barrier deadline.

scenario-results.json: PASS means the stated diagnostic assertion was observed; DEFECT_REPRODUCED is not correct gameplay. scenario-trace.json is the final diagnostic run. custom-probes-final-run.jsonl and trace-test_*.jsonl are observations, not a production replay stream. Earlier custom-probes files are retained intermediate runs; they are not extra independent scenarios. Three initial setup failures (missing docs/cards twice, missing synthetic cards table once) were corrected before the final suite runs.

Shutdown ONLY this lab server with mysqladmin --no-defaults --host=127.0.0.1 --port=33387 --user=root --password=stage3_local_only shutdown, after rechecking datadir. Do not remove the retained datadir or logs automatically. Physical process crashes, network lost COMMIT acknowledgement and full browser transport loss were not simulated in this run.
