CREATE DATABASE berserk_stage3 CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
CREATE USER 'stage3'@'127.0.0.1' IDENTIFIED BY 'stage3_test_only';
GRANT ALL PRIVILEGES ON berserk_stage3.* TO 'stage3'@'127.0.0.1';
USE berserk_stage3;
CREATE TABLE games(ind INT NOT NULL AUTO_INCREMENT PRIMARY KEY,host_id INT NOT NULL,player_id INT NOT NULL,status VARCHAR(32) NOT NULL,json LONGTEXT NOT NULL,version INT NOT NULL DEFAULT 0,date DATETIME,active INT DEFAULT 1) ENGINE=InnoDB;
SELECT @@port,@@datadir,@@version;
SHOW TABLE STATUS LIKE 'games';
