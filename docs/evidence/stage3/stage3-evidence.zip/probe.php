<?php
function stage3_probe($state,string $point):void {
 $path=getenv('STAGE3_TRACE');
 if(!$path || !str_contains(str_replace('\\','/',$path),'/stage3-verification/results/'))return;
 file_put_contents($path,json_encode(['point'=>$point,'state'=>$state->toArray()],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR)."\n",FILE_APPEND|LOCK_EX);
 if(function_exists('capture'))capture($state,'probe:'.$point);
}
