# Stage 4A.1 verification without SQL triggers

Branch codex/battle-replay-stage4a, HEAD 2755c79a6f20c98725b8d9709188884f2c902ce2. Existing Stage4A/Stage3 evidence is retained unchanged. No production SQL or configuration was used.

The retained disposable MariaDB 10.8.4 server owns C:/Users/mi/Documents/Berserk/stage4a-verification/data, port33389, bind127.0.0.1, --no-defaults. It was restarted hidden for this task and stopped after verification. PHP8.1.9 uses that lab's own php.ini and session/error paths. New results live at C:/Users/mi/Documents/Berserk/stage4a1-verification; no actual database files, config or runtime storage are included in this archive.

Create a NEW empty berserk_stage4a_runN schema on the verified isolated server, never DROP earlier data. Use account stage4a1 with disposable password stage4a1_test_only and ONLY SELECT,INSERT,UPDATE,DELETE,CREATE,DROP,REFERENCES,INDEX,ALTER on that schema, global USAGE only. Do NOT grant TRIGGER or ALL PRIVILEGES. Final run is berserk_stage4a_run7; initial run6 is retained. Verify @@datadir and port before any setup. Test guard checks exact datadir/port, synthetic schema name, absence of .git and BERSERK_STAGE4A_ISOLATED=1.

Use reviewed src/tools in the isolated app copy C:/Users/mi/Documents/Berserk/stage4a-verification/app. Set STAGE4A_SCHEMA=berserk_stage4a_runN and STAGE4A_RESULTS=<new empty output directory>, then run C:/OSPanel/modules/php/PHP_8.1/php.exe -c <lab>/php.ini <app>/tools/test_battle_history.php. Script requires a fresh schema without games, creates synthetic games/journal then five history tables. Worker subprocesses use same env/ini. All 23 checks must PASS, no SKIP. Source-integrity.json identifies delivered new bytes and the original 163 source files.

No triggers are created by migration OR tests. Failure at the second required event/snapshot INSERT is injected using an isolated-only ALTER ADD CHECK scoped to the synthetic game. Whole caller transaction rolls back; test removes that temporary CHECK afterward and proves successful retry with no sequence gaps. Root read-only metadata separately proves zero triggers in the final schema, explicit schema grants and only global USAGE; app SHOW GRANTS check also refuses ALL/TRIGGER.

Tamper tests directly UPDATE valid JSON/full state, each projection, and hash only in synthetic data. Both projection and full-history readers must throw integrity errors with no data returned, rehash or repair. Restore of original bytes happens only inside the test fixture. Legacy state-only checksum is refused. Unicode/newline/slash/quote data verifies hashing exact final bytes. There is no production mutation API.

Run the read-only tools/migrations/20261020_battle_history_postchecks.sql against the synthetic schema via mysql client SOURCE (or queries individually). Exit0 output is retained. It contains SELECT/SHOW only. It is the ONLY file proposed for current production verification; production tables already exist and CREATE migration must not be rerun there.

Old regressions ran from the isolated app with its synthetic berserk_stage4a_regression config, never production config. PHPRC=<lab>/php.ini for endpoint subprocesses. BERSERK_STAGE31_ISOLATED=1 and STAGE31_RESULTS=<stage4a1-results>/results/stage31.json for 33 targeted cases. All 18 existing suites plus targeted test have exit0/noSKIP, listed in regressions/summary.json. They do not integrate the new component.

Physical COMMIT ACK loss/crash/power-failure are not tested; durable response-discard retry and concurrency checks remain. SHA-256 is not a signature and cannot protect against deliberate SQL content+hash replacement or external deletion. Never infer physical immutability without privileges/triggers.

Retain results/data. Stop only the verified lab server via mysqladmin on port33389 after checking actual datadir. Do not start Stage4B/Recorder, merge, deploy or production SQL.
