# Stage 3.1 isolated regression evidence

Baseline main: 6be7d6875b7ac99c98b88b29061b0eba4dc6ee03. Branch: codex/battle-replay-stage3. No production DB/config/storage is used.

Original test lab: C:/Users/mi/Documents/Berserk/stage3-1-verification. Retained for reproduction, do not overwrite. A fresh reproduction must use an empty disposable tree, copying only src/tools/templates/www/docs to app, not .git/config/storage or real matches. The targeted scripts refuse a checkout with .git and require BERSERK_STAGE31_ISOLATED=1. They write ordinary GameLog files only in the isolated app/storage.

Runtime: C:/OSPanel/modules/php/PHP_8.1/php.exe 8.1.9, separate php.ini loading mysqli/mbstring and setting session.save_path to lab/sessions, error_log to lab/results/php-errors.log. Set PHPRC to the same test ini for controller subprocesses.

Database: new MariaDB 10.8.4 instance initialized with mysql_install_db.exe in lab/data, port 33388, no Windows service. Start mysqld with --no-defaults, --bind-address=127.0.0.1, --port=33388, --datadir=<lab>/data, log below lab/results. Verify SELECT @@datadir,@@port before setup.sql. Never substitute an existing database server. Test root password stage31_local_only and app password stage31_test_only are new disposable credentials, not production credentials. Execute setup.sql and fixture-schema.sql only against this server. App config must select host 127.0.0.1:33388, user stage31, name berserk_stage31. Database test additionally checks @@datadir and port. All app user privileges are limited to berserk_stage31.*. No product migrations/event/snapshot tables.

Run test_stage31_fixes.php with STAGE31_RESULTS pointing to a file in lab/results. It performs 31 deterministic in-memory Engine scenarios, JSON serialization between commands and ordinary diagnostic state copies; no diagnostic modifications to engine sources are needed. Run the identical tests/fixtures against unmodified baseline src in baseline-app with its own empty storage to reproduce 20 failures / 11 passes. The patched app gets 31 passes. Initial harness development errors are not baseline results; the final identical test files are retained.

Run test_stage31_persistence.php for 6 InnoDB/Command Journal scenarios. It loads shared fixtures only, assigns synthetic positive games and reloads actual persisted state after every command. It checks duplicate committed command ids without rerunning Engine. R2 cancel retry must not consume the next pending item. H1 immediately ends the turn without an intervening card action. Auto ACK uses a deterministic server clock at the recorded deadline.

Run the 18 suites listed in summary.json, one PHP process each, with the same isolated ini/config. Bon/Berrow and Swamp children require docs/cards fixtures; endpoint tests require the synthetic cards/elements schema. SKIP is not PASS. Final output logs and JSON results are in results/. States are diagnostic evidence, not an implemented replay format.

Source integrity: results/source-hashes.json verifies 163 PHP files. Only the 7 intended R1/R2/R3 source files differ from baseline. The delivered src bytes equal the tested app bytes. GameLog, CommandJournalRepository, GameRepository and Hydra mechanics are unchanged. No transient probe hooks were used in Stage 3.1. SQL DDL from repository constructors occurs only in the isolated database.

Shutdown only the verified lab server using mysqladmin --no-defaults --host=127.0.0.1 --port=33388 --user=root --password=stage31_local_only shutdown. Retain datadir/logs; no automatic recursive cleanup. This evidence does not claim physical network-loss, mysqld-crash or power-failure testing.
