<!DOCTYPE html>
<html lang="ru" class="{{page_class}}">
<head>
    <meta charset="UTF-8">
    <title>Berserk — партия #{{game_id}}</title>
    <meta name="viewport" content="width=device-width,initial-scale=1.0">
    <link rel="stylesheet" href="/assets/css/global.css?v={{rkey}}">
    {{page_styles}}
</head>
<body class="{{page_class}}">
<div class="screen">
    {{screen}}
</div>
{{scripts}}
</body>
</html>
