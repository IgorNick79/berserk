<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
$db=new Berserk\Core\Db(require __DIR__.'/app/config/db.php');$ids=json_decode(file_get_contents(__DIR__.'/fixtures.json'),true);$out=['environment'=>$db->fetchOne('SELECT @@datadir datadir,@@port port,DATABASE() db,VERSION() version'), 'grants'=>$db->fetchAll('SHOW GRANTS'), 'triggers'=>$db->fetchAll("SELECT TRIGGER_NAME FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE()"),'matches'=>[]];
foreach($ids as$name=>$g){$x=['game'=>$db->fetchOne("SELECT * FROM games WHERE ind=$g")];foreach(['matches','batches','actions','events','steps']as$t)$x[$t]=$db->fetchAll("SELECT * FROM battle_history_$t WHERE game_id=$g");$out['matches'][$name]=$x;}
file_put_contents(__DIR__.'/transaction-proof.json',json_encode($out,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_PRETTY_PRINT));
