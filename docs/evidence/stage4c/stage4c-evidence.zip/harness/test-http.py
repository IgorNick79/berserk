import urllib.request,urllib.parse,urllib.error,http.cookiejar,json,subprocess,os,re,pathlib,traceback
lab=pathlib.Path(__file__).parent; base='http://127.0.0.1:33492'; php='C:/OSPanel/modules/php/PHP_8.1/php.exe'
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
ids=json.loads((lab/'fixtures.json').read_text()); results=[]
def db(g,kind='all'):
 p=subprocess.run([php,str(lab/'inspect.php'),str(g),kind],capture_output=True,text=True,encoding='utf-8-sig',check=True)
 return json.loads(p.stdout) if p.stdout.strip() else None
def client(user):
 c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));request(c,'/lab-login.php?key=stage4c_local_fixture_only&user='+str(user));return c
def request(c,path,data=None):
 try:
  with c.open(base+path,None if data is None else urllib.parse.urlencode(data).encode())as r:return r.status,r.read().decode('utf-8-sig')
 except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8-sig')
cs={u:client(u)for u in [0,1,2,3,99]}
def test(name,fn):
 try: detail=fn();results.append(dict(name=name,status='PASS',detail=detail));print('PASS',name,flush=True)
 except Exception as e:results.append(dict(name=name,status='FAIL',error=str(e)));print('FAIL',name,str(e),flush=True);traceback.print_exc()
def check(b,msg):
 if not b:raise AssertionError(msg)
def prep(g,u,cmd='confirm_place',**payload):
 role='first'if u==1 else'second';code,html=request(cs[u],f'/index.php?{role}&game={g}');check(code==200,'prep page '+str(code)+html[:200]);
 token=re.search(r'prepare_token=([a-f0-9]+)',html);check(token,'prep token absent '+html[:200]);v=db(g,'state')['version']
 q=dict(game=g,cmd=cmd,prepare_version=v,prepare_token=token[1],**payload);return request(cs[u],'/index.php?'+role+'&'+urllib.parse.urlencode(q))
def start(g):
 for u in [1,2]:
  code,html=prep(g,u);check(code==200,'confirm HTTP '+str(code)+html[:300])
 check(db(g,'state')['status']=='battle','battle start');return db(g,'steps')
def command(g,u,typ,**payload):
 role='first'if u==1 else'second';v=db(g,'state')['version'];data=dict(cmd=typ,expected_version=v,command_id='c4c:'+os.urandom(10).hex(),**payload)
 code,body=request(cs[u],f'/index.php?{role}&game={g}&ajax=battle_command',data);check(code==200,f'{typ} HTTP {code} {body[:500]}');j=json.loads(body);check(j.get('ok'),f'{typ} {str(j)[:600]}');return j
def state(g):return json.loads(db(g,'state')['json'])
def combat(g,target=2):command(g,1,'strike',card_id=1,target_id=target);finish(g)
def finish(g):
 for _ in range(12):
  s=state(g);x=s.get('battle',{}).get('strike');
  if s['status']=='game_over'or not x:return
  mode=x['state']
  if mode=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
  elif mode=='waiting_choice':command(g,1 if x['choice_winner']=='attack'else 2,'choose_strike_mode',mode='normal')
  elif mode=='results':
   # token comes from persisted informational_wait DTO
   for u,key in [(1,'host'),(2,'player')]:
    s=state(g);x=s['battle'].get('strike');
    if not x:break
    if key not in x.get('confirmed',[]):
     wait=s['battle'].get('informational_wait',{});command(g,u,'confirm_strike',wait_id=wait.get('wait_id',wait.get('id',0)))
  else:raise AssertionError('wait '+mode)
 raise AssertionError('combat unfinished')
def api(g,kind='metadata',step=None,user=1):
 return request(cs[user],'/replay.php?'+urllib.parse.urlencode(dict(game=g,api=kind,**({'step':step}if step else{}))))
def initial():
 g=ids['ordinary'];code,body=prep(g,1,'place_card',card_id=3,row=2,col=3);check(code==200,'placement '+str(code)+body[:200]);r=start(g);check([x['step_type']for x in r]==['initial','battle_ready'],'initial types');check(len(set(x['journal_id']for x in r))==1,'atomic initial');return [dict(step=x['step_seq'],type=x['step_type'],journal=x['journal_id'])for x in r]
def prep_access():
 g=ids['ordinary'];before=db(g)
 code,body=request(cs[0],f'/index.php?first&game={g}');check(code==403,'legacy role control allowed')
 code,body=request(cs[1],f'/index.php?first&game={g}&cmd=confirm_place');check(code==403,'csrf accepted')
 check(db(g)==before,'invalid prep wrote state');return 'trusted principal and CSRF enforced before preparation write'
test('gated preparation rejects legacy identity and missing CSRF',prep_access)
test('real HTTP placement confirmations and atomic initial/battle_ready',initial)
test('HTTP move',lambda:command(ids['ordinary'],1,'move',card_id=1,row=3,col=2))
test('active full preview forbidden',lambda:(start(ids['active']),check(api(ids['active'])[0]==409,'active leak')))
def ordinary():
 g=ids['ordinary'];command(g,1,'end_turn');command(g,2,'end_turn');command(g,1,'move',card_id=1,row=3,col=3);combat(g);command(g,1,'resign');check(db(g,'state')['status']=='game_over','terminal');return [x['step_type']for x in db(g,'steps')]
test('HTTP turns combat choices ACK and terminal',ordinary)
def hydra():
 g=ids['voluntary'];start(g);combat(g);command(g,1,'attack_series_end');command(g,1,'end_turn');command(g,2,'resign');r=db(g,'steps');check([x['step_type']for x in r][2:5]==['combat','series_end','turn_end'],'Hydra steps');return [x['step_type']for x in r]
test('Hydra voluntary End and turn are separate HTTP frames',hydra)
def natural():
 g=ids['natural'];start(g);combat(g);command(g,1,'attack_series_next',target_id=4);finish(g);command(g,1,'resign');r=db(g,'steps');check('series_end'not in[x['step_type']for x in r],'synthetic End');return [x['step_type']for x in r]
test('Hydra natural close in combat without End',natural)
def gap():
 g=ids['gap'];start(g);command(g,1,'resign');code,body=api(g);check(code==200 and json.loads(body)['gaps'],'missing gaps');code,page=request(cs[1],f'/replay.php?game={g}');check('recording_gap'in page,'gap UI');return json.loads(body)
test('unsupported mechanic explicitly marks gaps in API and UI',gap)
def disabled():
 g=ids['disabled'];code,page=request(cs[0],f'/index.php?first&game={g}&recording_enabled=1');check(code==200 and 'prepare_token'not in page,'default gate');
 for role in ['first','second']:
  code,page=request(cs[0],f'/index.php?{role}&game={g}&cmd=confirm_place&recording_enabled=1');check(code==200,'disabled begin')
 command(g,1,'resign');check(not db(g,'steps'),'unapproved recording');return 'ordinary match works; request parameters do not enable history'
test('unlisted game unchanged and request opt-in ignored',disabled)
def auth():
 g=ids['voluntary'];check(api(g,user=0)[0]==401,'legacy role session accepted');check(api(g,user=3)[0]==403,'outsider');check(api(g,user=2)[0]==200,'participant');check(api(g,user=99)[0]==200,'admin');check(api(g,'step',999)[0]==404,'invalid step');return 'legacy/outsider rejected; participant/admin accepted'
test('API authentication authorization and step bounds',auth)
def readonly():
 g=ids['voluntary'];before=db(g)
 for typ in ['metadata','steps','step']:
  code,b=api(g,typ,1);check(code==200,'read '+typ)
 for n in [1,2,3,4,5,6,3]:
  code,page=request(cs[1],f'/replay.php?game={g}&step={n}');check(code==200,'page '+str(n));check('battle-sync.js'not in page and 'cmd='not in page,'game controls');(lab/f'frame-{n}.html').write_text(page,encoding='utf-8')
 check(db(g)==before,'view mutated data');return 'all seven SQL tables including games JSON/version/timers/pending and journal byte-identical'
test('real HTTP frame navigation preserves all persisted state',readonly)
def lethal():
 g=ids['lethal'];start(g);combat(g);check(db(g,'state')['status']=='game_over','lethal not terminal');check(api(g)[0]==200,'lethal replay');return [x['step_type']for x in db(g,'steps')]
test('actual HTTP lethal strike terminal snapshot',lethal)
def automatic():
 g=ids['automatic'];start(g);command(g,1,'strike',card_id=1,target_id=2)
 s=state(g)
 if s['battle']['strike']['state']=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
 s=state(g);command(g,1,'confirm_strike',wait_id=s['battle']['informational_wait']['wait_id'])
 # Time shift only the isolated fixture, then use the real sync/automatic route.
 subprocess.run([php,str(lab/'expire.php'),str(g)],check=True,capture_output=True)
 code,body=request(cs[2],f'/index.php?second&game={g}&ajax=battle_sync');check(code==200,'automatic HTTP')
 r=db(g,'steps');check(any(x['step_type']=='combat'for x in r),'automatic ACK combat not captured')
 command(g,1,'resign');return [x['step_type']for x in db(g,'steps')]
test('real automatic HTTP ACK uses same Recorder gate',automatic)
def hydra_ui():
 g=ids['voluntary'];values=[];original=None
 for n in [3,4,5,3]:
  code,body=api(g,'step',n);check(code==200,'Hydra API');c=next(x for x in json.loads(body)['state']['cards']if x['instance_id']=='1');values.append(c['closed'])
  code,html=request(cs[1],f'/replay.php?game={g}&step={n}');check(f'data-card-id="1" data-closed="{str(c["closed"]).lower()}"'in html,'Hydra markup')
  if n==3:
   if original is None:original=body
   else:check(body==original,'earlier frame changed')
 check(values==[False,True,True,False],'Hydra values');return values
test('Hydra UI renders immutable open closed turn frames',hydra_ui)
def select_only():
 config=lab/'app/config/db.php';old=config.read_text();config.write_text(old.replace("'user'=>'stage4b'","'user'=>'stage4c_read'").replace("'pass'=>'stage4b_test_only'","'pass'=>'stage4c_read_only'"))
 try:
  for kind in ['metadata','steps','step']:
   code,body=api(ids['voluntary'],kind,1);check(code==200,'SELECT-only API '+str(code)+body[:100])
  code,body=request(cs[1],f'/replay.php?game={ids["voluntary"]}&step=3');check(code==200,'SELECT-only UI')
 finally:config.write_text(old)
 return 'API and UI succeed with SELECT-only SQL account; DML/DDL cannot succeed'
test('API and UI operate with SELECT-only database privileges',select_only)
def integrity():
 g=ids['ordinary'];db(g,'tamper');check(api(g,'step',1)[0]==409,'corruption accepted');return 'tampered hash rejected before returning full data'
test('SHA256 corruption fails closed',integrity)
(lab/'http-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
raise SystemExit(any(x['status']=='FAIL'for x in results))
