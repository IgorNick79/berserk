<?php
putenv('BERSERK_STAGE31_ISOLATED=1');require __DIR__.'/app/tools/stage31_fixtures.php';
$db=new Berserk\Core\Db(require __DIR__.'/app/config/db.php');$repo=new Berserk\Core\GameRepository($db);$row=$repo->create(1,2);$s=s31state(['unanswer'=>true]);$s->gameId=$row->gameId;$s->hostId=1;$s->playerId=2;$s->getPlayer('host')->userId=1;$s->getPlayer('player')->userId=2;$s->persistenceVersion=$row->persistenceVersion;$s->persistenceJson=$row->persistenceJson;$s->status='place';$repo->save($s);
$c=require __DIR__.'/app/config/battle_history.local.php';$c['record_game_ids'][]=$s->gameId;$c['preview_game_ids'][]=$s->gameId;file_put_contents(__DIR__.'/app/config/battle_history.local.php','<?php return '.var_export($c,true).';');echo $s->gameId;
