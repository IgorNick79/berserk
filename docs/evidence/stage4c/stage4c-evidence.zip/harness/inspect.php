<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
$db=new Berserk\Core\Db(require __DIR__.'/app/config/db.php');$g=(int)($argv[1]??0);
if(($argv[2]??'')==='state'){echo json_encode($db->fetchOne("SELECT * FROM games WHERE ind=$g"));exit;}
if(($argv[2]??'')==='steps'){echo json_encode($db->fetchAll("SELECT * FROM battle_history_steps WHERE game_id=$g ORDER BY step_seq"));exit;}
if(($argv[2]??'')==='tamper'){$db->query("UPDATE battle_history_steps SET state_hash=REPEAT('0',64) WHERE game_id=$g AND step_seq=1");exit;}
$out=[];foreach(['games','battle_command_journal','battle_history_matches','battle_history_batches','battle_history_actions','battle_history_events','battle_history_steps']as$t)$out[$t]=$db->fetchAll("SELECT * FROM $t".($t==='games'?" WHERE ind=$g":" WHERE game_id=$g"));echo json_encode($out);
