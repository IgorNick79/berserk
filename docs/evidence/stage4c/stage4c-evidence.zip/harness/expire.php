<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
$db=new Berserk\Core\Db(require __DIR__.'/app/config/db.php');$g=(int)$argv[1];if($g<9000001||$db->fetchOne('SELECT DATABASE() db')['db']!=='berserk_stage4b_run10')throw new RuntimeException('Lab only');
$row=$db->fetchOne("SELECT json FROM games WHERE ind=$g");$s=json_decode($row['json'],true);$s['battle']['informational_wait']['started_at']=time()-11;$s['battle']['informational_wait']['deadline_at']=time()-1;
$db->query("UPDATE games SET json='".$db->escape(json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))."' WHERE ind=$g");
