const {chromium}=require('C:/Users/mi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path');
(async()=>{
 const lab=__dirname, ids=JSON.parse(fs.readFileSync(path.join(lab,'fixtures.json'),'utf8'));
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 const page=await browser.newPage({viewport:{width:1280,height:1000}});const errors=[];page.on('pageerror',e=>errors.push(String(e)));
 await page.goto('http://127.0.0.1:33492/lab-login.php?key=stage4c_local_fixture_only&user=1');
 const g=ids.voluntary;await page.goto(`http://127.0.0.1:33492/replay.php?game=${g}&step=3`);
 const check=(ok,msg)=>{if(!ok)throw Error(msg)};const states=[];
 async function capture(label){
  check(await page.locator('[data-card-id="1"]').count()===1,'Hydra not rendered');
  const closed=await page.locator('[data-card-id="1"]').getAttribute('data-closed');states.push(closed);
  await page.screenshot({path:path.join(lab,`ui-${label}.png`),fullPage:true});return closed;
 }
 check((await capture('combat'))==='false','combat closed');
 await page.locator('#replay-next').click();check((await capture('series-end'))==='true','series End open');
 await page.locator('#replay-next').click();check((await capture('turn-end'))==='true','turn open');
 await page.locator('#replay-prev').click();await page.locator('#replay-prev').click();check((await capture('combat-return'))==='false','earlier frame mutated');
 await page.locator('#replay-first').click();check((await page.locator('#replay-step').textContent()).includes('Кадр 1 /'),'first');
 await page.locator('#replay-last').click();check((await page.locator('#replay-step').textContent()).includes('Завершение боя'),'last');
 check(await page.locator('script,form,button,[href*="cmd="]').count()===0,'game controls/scripts');
 await page.goto(`http://127.0.0.1:33492/replay.php?game=${ids.natural}&step=4`);await capture('natural-combat');
 await page.goto(`http://127.0.0.1:33492/replay.php?game=${ids.gap}`);check((await page.textContent('body')).includes('recording_gap'),'gap absent');await page.screenshot({path:path.join(lab,'ui-gap.png'),fullPage:true});
 check(errors.length===0,'JS errors');fs.writeFileSync(path.join(lab,'ui-summary.json'),JSON.stringify({status:'PASS',browser:'Edge headless / Playwright',states,errors,navigation:'first/prev/next/last clicked; only saved HTML GET pages'},null,2));
 await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
