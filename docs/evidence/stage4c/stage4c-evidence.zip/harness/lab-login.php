<?php
if(($_GET['key']??'')!=='stage4c_local_fixture_only'||!in_array((int)($_GET['user']??0),[0,1,2,3,99],true)){http_response_code(403);exit;}
session_start();$_SESSION=[];$u=(int)$_GET['user'];if($u)$_SESSION['berserk_authenticated_user_id']=$u;else $_SESSION['user_id']=1;
$_SESSION['debug_roll']='6*';echo 'lab login';
