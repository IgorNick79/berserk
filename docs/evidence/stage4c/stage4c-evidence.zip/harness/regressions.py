import subprocess,os,json,pathlib
lab=pathlib.Path('stage4c-verification');out=lab/'regressions';out.mkdir(exist_ok=True)
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini';os.environ['BERSERK_STAGE31_ISOLATED']='1';os.environ['STAGE31_RESULTS']=str(out.resolve()/'stage31.json')
assert "'name'=>'berserk_stage4b_run10'"in(lab/'app/config/db.php').read_text()
names=['test_stage31_fixes','test_hydra','test_ragnar','test_combat_instant_phases','test_degasca','test_bon_and_berrow','test_swamp_children','test_movement_effects','test_forced_directional_movement','test_volkhv_wound_transfer','test_resign_pending','test_nested_combat_ownership','test_command_journal_repository','test_battle_command_endpoint','test_turn_timer','test_informational_wait','test_turn_timeout','test_pending_wait_timer','test_turn_instant_stack','test_match_player_settings','test_match_pause']
summary=[]
for name in names:
 p=subprocess.run(['C:/OSPanel/modules/php/PHP_8.1/php.exe',str(lab/'app/tools'/f'{name}.php')],capture_output=True)
 text=(p.stdout+p.stderr).decode('utf-8',errors='replace');(out/f'{name}.txt').write_text(text,encoding='utf-8');item=dict(suite=name,exit=p.returncode,skip='skip'in text.lower());summary.append(item);print(item,flush=True)
(out/'summary.json').write_text(json.dumps(summary,indent=2))
raise SystemExit(any(x['exit']or x['skip']for x in summary))
