<?php
putenv('BERSERK_STAGE31_ISOLATED=1');
require __DIR__.'/app/tools/stage31_fixtures.php';
use Berserk\Core\{Db,GameRepository,CommandJournalRepository};
$db=new Db(require __DIR__.'/app/config/db.php');
$p=$db->fetchOne('SELECT @@port port,@@datadir dir');if((int)$p['port']!==33389||!str_contains(strtolower(str_replace('\\','/',$p['dir'])),'/berserk/stage4a-verification/data/'))throw new RuntimeException('Wrong lab');
$sql=preg_replace('/^USE .*;$/m','',file_get_contents(__DIR__.'/../stage4b-verification/regression-fixtures.sql'));
foreach(explode(';',$sql)as$q)if(trim($q)!=='')$db->query($q);
$db->query('ALTER TABLE games AUTO_INCREMENT=9000001');
new CommandJournalRepository($db);
$sql=preg_replace('/^--.*$/m','',file_get_contents(__DIR__.'/app/tools/migrations/20261020_battle_history.sql'));
foreach(explode(';',$sql)as$q)if(trim($q)!=='')$db->query($q);
$cat=[];foreach([1,2,3,4,90,91]as$id){$cat['s31_'.$id]=['revision'=>'http-v1','name'=>$id===1?'Гидра (test)':'Карта '.$id,'image'=>'','description'=>'Frozen HTTP fixture','type'=>'creature','element'=>'neutral','classes'=>[],'price'=>0];$db->query("INSERT INTO cards(ind,ukid,name,health,move,strike_weak,strike_medium,strike_strong,prop,descr) VALUES(".(100+$id).",'s31_$id','Test $id',20,1,2,3,4,'{}','')");}
$repo=new GameRepository($db);$ids=[];
foreach(['voluntary','natural','ordinary','active','gap','disabled','lethal','automatic']as$name){
 $row=$repo->create(1,2);$s=s31state(in_array($name,['voluntary','natural'],true)?['attack_series'=>true,'unanswer'=>true]:['unanswer'=>true]);
 $s->gameId=$row->gameId;$s->hostId=1;$s->playerId=2;$s->getPlayer('host')->userId=1;$s->getPlayer('player')->userId=2;
 $s->persistenceVersion=$row->persistenceVersion;$s->persistenceJson=$row->persistenceJson;$s->status='place';
 // Both confirmations are real HTTP commands. Card3 starts in squad for a real place_card.
 if($name==='ordinary'){$s->getCard(3)->zone='squad';$s->getCard(3)->row=null;$s->getCard(3)->col=null;}
 if($name==='lethal'){unset($s->cards[4],$s->cards[91]);$s->getCard(2)->hp=1;}
 if($name==='gap')$s->getCard(1)->prop['coin']=true;
 $repo->save($s);$ids[$name]=$s->gameId;
}
$config=['recording_enabled'=>true,'record_game_ids'=>array_values(array_diff_key($ids,['disabled'=>true])), 'preview_enabled'=>true,'preview_game_ids'=>array_values($ids),'admin_user_ids'=>[99],'catalog'=>$cat];
file_put_contents(__DIR__.'/app/config/battle_history.local.php','<?php return '.var_export($config,true).';');
file_put_contents(__DIR__.'/fixtures.json',json_encode($ids));echo json_encode($ids);
