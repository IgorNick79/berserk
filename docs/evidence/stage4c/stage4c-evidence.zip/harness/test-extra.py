import urllib.request,urllib.parse,urllib.error,http.cookiejar,json,subprocess,os,re,pathlib,traceback
lab=pathlib.Path(__file__).parent; base='http://127.0.0.1:33492'; php='C:/OSPanel/modules/php/PHP_8.1/php.exe'
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
ids=json.loads((lab/'fixtures.json').read_text()); results=[]
def db(g,kind='all'):
 p=subprocess.run([php,str(lab/'inspect.php'),str(g),kind],capture_output=True,text=True,encoding='utf-8-sig',check=True)
 return json.loads(p.stdout) if p.stdout.strip() else None
def client(user):
 c=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()));request(c,'/lab-login.php?key=stage4c_local_fixture_only&user='+str(user));return c
def request(c,path,data=None):
 try:
  with c.open(base+path,None if data is None else urllib.parse.urlencode(data).encode())as r:return r.status,r.read().decode('utf-8-sig')
 except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8-sig')
cs={u:client(u)for u in [0,1,2,3,99]}
def test(name,fn):
 try: detail=fn();results.append(dict(name=name,status='PASS',detail=detail));print('PASS',name,flush=True)
 except Exception as e:results.append(dict(name=name,status='FAIL',error=str(e)));print('FAIL',name,str(e),flush=True);traceback.print_exc()
def check(b,msg):
 if not b:raise AssertionError(msg)
def prep(g,u,cmd='confirm_place',**payload):
 role='first'if u==1 else'second';code,html=request(cs[u],f'/index.php?{role}&game={g}');check(code==200,'prep page '+str(code)+html[:200]);
 token=re.search(r'prepare_token=([a-f0-9]+)',html);check(token,'prep token absent '+html[:200]);v=db(g,'state')['version']
 q=dict(game=g,cmd=cmd,prepare_version=v,prepare_token=token[1],**payload);return request(cs[u],'/index.php?'+role+'&'+urllib.parse.urlencode(q))
def start(g):
 for u in [1,2]:
  code,html=prep(g,u);check(code==200,'confirm HTTP '+str(code)+html[:300])
 check(db(g,'state')['status']=='battle','battle start');return db(g,'steps')
def command(g,u,typ,**payload):
 role='first'if u==1 else'second';v=db(g,'state')['version'];data=dict(cmd=typ,expected_version=v,command_id='c4c:'+os.urandom(10).hex(),**payload)
 code,body=request(cs[u],f'/index.php?{role}&game={g}&ajax=battle_command',data);check(code==200,f'{typ} HTTP {code} {body[:500]}');j=json.loads(body);check(j.get('ok'),f'{typ} {str(j)[:600]}');return j
def state(g):return json.loads(db(g,'state')['json'])
def combat(g,target=2):command(g,1,'strike',card_id=1,target_id=target);finish(g)
def finish(g):
 for _ in range(12):
  s=state(g);x=s.get('battle',{}).get('strike');
  if s['status']=='game_over'or not x:return
  mode=x['state']
  if mode=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
  elif mode=='waiting_choice':command(g,1 if x['choice_winner']=='attack'else 2,'choose_strike_mode',mode='normal')
  elif mode=='results':
   # token comes from persisted informational_wait DTO
   for u,key in [(1,'host'),(2,'player')]:
    s=state(g);x=s['battle'].get('strike');
    if not x:break
    if key not in x.get('confirmed',[]):
     wait=s['battle'].get('informational_wait',{});command(g,u,'confirm_strike',wait_id=wait.get('wait_id',wait.get('id',0)))
  else:raise AssertionError('wait '+mode)
 raise AssertionError('combat unfinished')
def api(g,kind='metadata',step=None,user=1):
 return request(cs[user],'/replay.php?'+urllib.parse.urlencode(dict(game=g,api=kind,**({'step':step}if step else{}))))
def initial():
 g=ids['ordinary'];code,body=prep(g,1,'place_card',card_id=3,row=2,col=3);check(code==200,'placement '+str(code)+body[:200]);r=start(g);check([x['step_type']for x in r]==['initial','battle_ready'],'initial types');check(len(set(x['journal_id']for x in r))==1,'atomic initial');return [dict(step=x['step_seq'],type=x['step_type'],journal=x['journal_id'])for x in r]
def prep_access():
 g=ids['ordinary'];before=db(g)
 code,body=request(cs[0],f'/index.php?first&game={g}');check(code==403,'legacy role control allowed')
 code,body=request(cs[1],f'/index.php?first&game={g}&cmd=confirm_place');check(code==403,'csrf accepted')
 check(db(g)==before,'invalid prep wrote state');return 'trusted principal and CSRF enforced before preparation write'

g=int(subprocess.run([php,str(lab/'extra.php')],capture_output=True,text=True,check=True).stdout)
def auto_turn():
 start(g);subprocess.run([php,str(lab/'expire-turn.php'),str(g)],check=True,capture_output=True)
 code,body=request(cs[2],f'/index.php?second&game={g}&ajax=battle_sync');check(code==200,'sync');check(state(g)['battle']['active']=='player','no automatic end');check(db(g,'steps')[-1]['step_type']=='turn_end','no recorded turn_end');command(g,2,'resign');return [x['step_type']for x in db(g,'steps')]
test('automatic HTTP turn_end uses server allowlist',auto_turn)
def traps():
 originals={}
 try:
  for file in ['Core/Engine.php','Core/GameRepository.php','Core/AutomaticBattleProgress.php','Core/HttpBattleProgress.php']:
   p=lab/'app/src'/file;originals[p]=p.read_bytes();text=p.read_text(encoding="utf-8");i=text.index('namespace Berserk');e=text.index(';',i)+1;text=text[:e]+" throw new \\RuntimeException('forbidden replay gameplay load');"+text[e:];p.write_text(text,encoding="utf-8")
  for typ in ['metadata','steps','step']:
   code,body=api(g,typ,1);check(code==200,'gameplay trap '+typ+str(code)+body[:100])
  code,body=request(cs[1],f'/replay.php?game={g}');check(code==200,'UI gameplay trap')
 finally:
  for p,value in originals.items():p.write_bytes(value)
 return 'Engine, GameRepository, AutomaticBattleProgress and HttpBattleProgress throw-on-load in disposable copy; all replay reads still succeed'
test('read endpoints never load gameplay or automatic progress',traps)
def no_config():
 p=lab/'app/config/battle_history.local.php';old=p.read_bytes();p.rename(p.with_suffix('.disabled'))
 try:
  code,body=api(g);check(code==404,'preview globally enabled')
  code,body=request(cs[1],'/index.php?first&game='+str(ids['disabled']));check(code==200,'ordinary game fails when config absent')
 finally:p.with_suffix('.disabled').rename(p)
 return 'absent local config disables recording and preview; normal game continues'
test('default-off without local configuration',no_config)
(lab/'extra-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
raise SystemExit(any(x['status']=='FAIL'for x in results))
