<?php
declare(strict_types=1);
if(getenv('BERSERK_STAGE4B_ISOLATED')!=='1'||!hash_equals(getenv('STAGE4B_HTTP_KEY'),$_SERVER['HTTP_X_FIXTURE_KEY']??'')){http_response_code(403);exit;}
require getenv('STAGE4B_HTTP_APP').'/src/Core/Autoloader.php';
Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',getenv('STAGE4B_HTTP_APP').'/src/');
$db=new Berserk\Core\Db(['host'=>'127.0.0.1:33389','user'=>'stage4b','pass'=>'stage4b_test_only','name'=>getenv('STAGE4B_SCHEMA')]);
$proof=$db->fetchOne('SELECT @@datadir dir,@@port port');
if((int)$proof['port']!==33389||strtolower(rtrim(str_replace('\\','/',$proof['dir']),'/'))!==strtolower('C:/Users/mi/Documents/Berserk/stage4a-verification/data'))throw new RuntimeException('Wrong server');
$g=(int)getenv('STAGE4B_HTTP_GAME');$catalog=json_decode(getenv('STAGE4B_HTTP_CATALOG'),true,512,JSON_THROW_ON_ERROR);
$repo=new Berserk\Core\GameRepository($db,new Berserk\Core\BattleHistory\ExperimentalHistory([$g],$catalog));
$j=new Berserk\Core\CommandJournalRepository($db);$s=$repo->findById($g);
$input=json_decode(file_get_contents('php://input'),true)??[];
$type=$input['type']??'confirm_place';$actor=$input['actor']??'player';$payload=$input['payload']??[];
if(!in_array($type,['confirm_place','strike','choose_defender','choose_strike_mode','confirm_strike'],true)||!in_array($actor,['host','player'],true))throw new RuntimeException('Fixture command not allowed');
$expected=$input['expected']??(int)getenv('STAGE4B_HTTP_VERSION');$id=$input['id']??'http-confirm-place';
$c=$j->registerProcessing($g,$actor,$id,$type,$payload,$expected);
$_SESSION=['debug_roll'=>'6*'];Berserk\Core\Dice::init();
if($c['is_new'])$repo->executeLockedCommand($s,$j,(int)$c['id'],fn($w)=>(new Berserk\Core\Engine())->apply($w,$actor,new Berserk\Core\Command($type,$payload)));
header('Content-Type: application/json');echo json_encode($j->findById((int)$c['id']));