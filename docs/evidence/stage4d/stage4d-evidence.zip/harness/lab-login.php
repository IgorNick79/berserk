<?php
if(($_GET['key']??'')!=='stage4d_local_only'){http_response_code(403);exit;}
$identities=json_decode(file_get_contents(__DIR__.'/../../identities.json'),true);session_start();$_SESSION=['debug_roll'=>'6*'];$id=$_GET['identity']??'';
if(isset($identities[$id]))$_SESSION['berserk_battle_journal_binding']=$identities[$id];else $_SESSION['user_id']=1;echo 'isolated session';
