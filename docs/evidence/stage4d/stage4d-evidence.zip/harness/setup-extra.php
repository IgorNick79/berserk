<?php
putenv('BERSERK_STAGE31_ISOLATED=1');require __DIR__.'/app/tools/stage31_fixtures.php';
use Berserk\Core\{Db,GameRepository};
$db=new Db(require __DIR__.'/app/config/db.php');if($db->fetchOne('SELECT DATABASE() db')['db']!=='berserk_stage4d_run3')throw new RuntimeException('Lab only');$repo=new GameRepository($db);$ids=json_decode(file_get_contents(__DIR__.'/fixtures.json'),true);$ident=json_decode(file_get_contents(__DIR__.'/identities.json'),true);$cfg=require __DIR__.'/app/config/battle_history.local.php';
foreach(['vampire','status','turn_label']as$name){$row=$repo->create(1,2);$s=s31state(['unanswer'=>true]);$s->gameId=$row->gameId;$s->hostId=1;$s->playerId=2;$s->getPlayer('host')->userId=1;$s->getPlayer('player')->userId=2;$s->status='place';$s->persistenceVersion=$row->persistenceVersion;$s->persistenceJson=$row->persistenceJson;
 if($name==='vampire'){$s->getCard(1)->prop['vampire']=true;$s->getCard(1)->hp=18;}
 if($name==='status')$s->getCard(3)->prop['instants']=[['key'=>'close','name'=>'Закрытие','trigger'=>'turn','when'=>'turn','phase'=>'turn','target'=>'any','effect'=>['type'=>'close_target']]];
 $repo->save($s);$ids[$name]=$s->gameId;$cfg['record_game_ids'][]=$s->gameId;$cfg['journal_game_ids'][]=$s->gameId;
 foreach(['host','player']as$side){$token=bin2hex(random_bytes(32));$cfg['journal_test_bindings'][$token]=['game_id'=>$s->gameId,'side'=>$side,'expires_at'=>time()+14400];$ident[$name.':'.$side]=$token;}
}
file_put_contents(__DIR__.'/fixtures.json',json_encode($ids));file_put_contents(__DIR__.'/identities.json',json_encode($ident));file_put_contents(__DIR__.'/app/config/battle_history.local.php','<?php return '.var_export($cfg,true).';');
