<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
use Berserk\Core\{Db,GameRepository,CommandJournalRepository,Engine,Command};use Berserk\Core\BattleHistory\HistoryRuntime;
$db=new Db(require __DIR__.'/app/config/db.php');if($db->fetchOne('SELECT DATABASE() db')['db']!=='berserk_stage4d_run3')throw new RuntimeException('lab only');$g=(int)$argv[1];$repo=HistoryRuntime::load()->repository($db);$j=new CommandJournalRepository($db);
if(($argv[2]??'')==='setup'){$s=$repo->findById($g);$ids=[];foreach(['a','b']as$key)$ids[]=$j->registerProcessing($g,'host','stage4d-concurrent-'.$key,'move',['key'=>$key],$s->persistenceVersion)['id'];echo json_encode($ids);exit;}
$c=$j->findById((int)$argv[2]);$s=$repo->findById($g);$s->persistenceVersion=(int)$c['expected_version'];
try{$repo->executeLockedCommand($s,$j,(int)$c['id'],function($locked)use($argv){file_put_contents($argv[3],'locked');if($argv[4]==='hold')usleep(900000);return(new Engine())->apply($locked,'host',new Command('move',['card_id'=>3,'row'=>2,'col'=>3]));});echo json_encode(['status'=>'committed']);}
catch(Throwable$e){echo json_encode(['status'=>'conflict','class'=>get_class($e)]);exit(2);}
