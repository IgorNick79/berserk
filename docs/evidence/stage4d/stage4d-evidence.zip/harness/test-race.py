from pathlib import Path
import subprocess,os,time,json
lab=Path(__file__).parent;g=json.loads((lab/'fixtures.json').read_text())['concurrent'];php='C:/OSPanel/modules/php/PHP_8.1/php.exe';os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
args=[php,str(lab/'race.php'),str(g)];ids=json.loads(subprocess.check_output(args+['setup']));marker=lab/('race-'+os.urandom(4).hex()+'.lock');p1=subprocess.Popen(args+[str(ids[0]),str(marker),'hold'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
end=time.monotonic()+8
while not marker.exists()and time.monotonic()<end:time.sleep(.01)
assert marker.exists(),'worker did not lock';p2=subprocess.Popen(args+[str(ids[1]),str(marker)+'2','now'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
out1,err1=p1.communicate();out2,err2=p2.communicate();assert p1.returncode==0 and p2.returncode==2,(out1,err1,out2,err2)
events=json.loads(subprocess.check_output([php,str(lab/'inspect.php'),str(g),'events']));moves=[x for x in events if x['event_type']=='move.started'];assert len(moves)==1,moves
assert [int(x['event_seq'])for x in events]==list(range(1,len(events)+1))
r={'status':'PASS','worker1':json.loads(out1),'worker2':json.loads(out2),'moves':len(moves),'contiguous_events':True};(lab/'race-summary.json').write_text(json.dumps(r,indent=2));print(r)
