from auth import *
from concurrent.futures import ThreadPoolExecutor
results=[]
def check(name,b):
 assert b,name
 results.append(dict(name=name,status='PASS'));print('PASS',name,flush=True)
g=ids['journal'];grant=issue(g,'host');c1=new_client();c2=new_client()
# Both clients fetch independent CSRF before simultaneous redemption.
def payload(c):
 code,body=req(c,'/journal-access.php');return dict(csrf=re.search(r'name="csrf" value="([a-f0-9]+)"',body)[1],invitation=grant['secret'])
a=payload(c1);b=payload(c2)
with ThreadPoolExecutor(2) as pool:codes=list(pool.map(lambda pair:req(pair[0],'/journal-access.php',pair[1])[0],[(c1,a),(c2,b)]))
check('concurrent redemption has exactly one winner',sorted(codes)==[200,403])
c=new_client();req(c,'/journal-access.php');jar=[h.cookiejar for h in c.handlers if isinstance(h,urllib.request.HTTPCookieProcessor)][0];old=list(jar)[0].value
redeem(c,issue(g,'player')['secret']);cookie=list(jar)[0]
check('session fixation rotation',old!=cookie.value)
check('cookie session only HttpOnly SameSite',cookie.expires is None and cookie.has_nonstandard_attr('HttpOnly') and cookie.get_nonstandard_attr('SameSite')=='Strict')
config=lab/'app/config/battle_history.local.php';original=config.read_bytes()
try:
 s=original.decode().replace("'journal_access_local_http' => true","'journal_access_local_http' => false");config.write_text(s,encoding='utf-8')
 check('non HTTPS denied outside explicit lab exception',req(new_client(),'/journal-access.php')[0]==403)
finally:config.write_bytes(original)
path=lab/'private-access/journal-access.json';original=path.read_bytes()
try:
 path.write_text('{bad')
 check('corrupt ledger fails closed',req(c,f'/battle-journal.php?game={g}')[0]==403)
finally:path.write_bytes(original)
(lab/'access-extra-summary.json').write_text(json.dumps(results,indent=2))
