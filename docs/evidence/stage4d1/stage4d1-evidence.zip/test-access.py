from auth import *
import time
results=[]
def check(name,b):
 assert b,name
 results.append(dict(name=name,status='PASS'));print('PASS',name,flush=True)
def journal(c,g):return req(c,'/battle-journal.php?game='+str(g))
g=ids['journal'];h=new_client();p=new_client();hi=issue(g,'host');pi=issue(g,'player')
check('first invitation',redeem(h,hi['secret'])[0]==200)
check('second independent invitation',redeem(p,pi['secret'])[0]==200)
check('invitation reuse rejected',redeem(new_client(),hi['secret'])[0]==403)
check('side spoof rejects before gameplay',req(h,f'/index.php?second&game={g}')[0]==403 and req(p,f'/index.php?first&game={g}')[0]==403)
check('foreign match denies',journal(h,ids['hidden'])[0]==403)
check('finished journal remains readable',journal(h,g)[0]==200 and journal(p,g)[0]==200)
check('full replay remains locked',req(h,f'/replay.php?game={g}')[0]==401)
check('fresh browser has no session',journal(new_client(),g)[0]==403)
check('restarted browser cannot reuse invitation',redeem(new_client(),pi['secret'])[0]==403)
check('csrf rejects',req(new_client(),'/journal-access.php',dict(csrf='a'*64,invitation=issue(g,'host')['secret']))[0]==403)
check('query string forbidden',req(new_client(),'/journal-access.php?game=1')[0]==400)
subprocess.run([php,str(lab/'app/tools/journal_access.php'),'revoke',hi['id']],capture_output=True,check=True)
check('revocation denies journal and gameplay',journal(h,g)[0]==403 and req(h,f'/index.php?first&game={g}')[0]==403)
e=new_client();grant=issue(g,'host',3);check('short access first works',redeem(e,grant['secret'])[0]==200);time.sleep(3)
check('expiry denies journal and gameplay',journal(e,g)[0]==403 and req(e,f'/index.php?first&game={g}')[0]==403)
raw=(lab/'private-access/journal-access.json').read_text()
check('ledger has no plaintext invite',hi['secret'] not in raw and pi['secret'] not in raw)
check('no secret in request log',hi['secret'] not in (lab/'http-errors.log').read_text())
check('ordinary match journal default OFF',journal(p,ids['disabled'])[0]==404)
(lab/'access-summary.json').write_text(json.dumps(results,indent=2))
