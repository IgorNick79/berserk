<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
try {$a=Berserk\Core\BattleHistory\HistoryRuntime::load()->invitations();$secret=json_decode(file_get_contents($argv[1]),true)['secret'];$a->consume($secret,fn()=>true);echo 'consumed';}catch(DomainException){exit(2);}
