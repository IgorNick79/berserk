const {chromium}=require('C:/Users/mi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path'),cp=require('child_process');
(async()=>{
 const lab=__dirname,ids=JSON.parse(fs.readFileSync(path.join(lab,'fixtures.json'),'utf8')),base='http://127.0.0.1:33494';
 const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
 const ctx1=await browser.newContext({viewport:{width:1360,height:1000}}),ctx2=await browser.newContext({viewport:{width:1360,height:1000}});
 const p1=await ctx1.newPage(),p2=await ctx2.newPage();let errors=[],nav=0;for(const p of[p1,p2])p.on('pageerror',e=>errors.push(String(e)));
 for(const [p,side,role]of[[p1,'host','first'],[p2,'player','second']]){
  const privateFile=path.join(lab,'private-access','browser-'+side+'.json');
  cp.execFileSync('C:/OSPanel/modules/php/PHP_8.1/php.exe',[path.join(lab,'app/tools/journal_access.php'),'issue',String(ids.ui),side,'3600',privateFile],{env:{...process.env,PHPRC:'C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'}});
  const invitation=JSON.parse(fs.readFileSync(privateFile,'utf8'));fs.unlinkSync(privateFile);
  await p.goto(`${base}/journal-access.php`);
  await p.locator('[name="invitation"]').fill(invitation.secret);await p.locator('[type="submit"]').click();
  await p.waitForURL(/index.php/);await p.goto(`${base}/index.php?${role}&game=${ids.ui}`);
  await p.locator('[data-action="battle-log"]').click();await p.locator('[data-journal-entries] li').first().waitFor();
 }
 p1.on('framenavigated',f=>{if(f===p1.mainFrame())nav++});
 await p1.evaluate(()=>{window.stage4dPanel=document.getElementById('battle-journal')});
 const runTurns=n=>new Promise((resolve,reject)=>cp.execFile('C:/Python312/python.exe',[path.join(lab,'ui-commands.py')],{env:{...process.env,UI_TURNS:String(n)},encoding:'utf8'},(e,out,err)=>e?reject(Error(out+err)):resolve(out)));
 await runTurns(18);
 await p1.waitForFunction(()=>document.querySelectorAll('[data-journal-entries] li').length>=30);
 const sc=p1.locator('[data-journal-scroll]');await sc.evaluate(e=>e.scrollTop=0);const count=await p1.locator('[data-journal-entries] li').count();
 await runTurns(2);await p1.waitForFunction(n=>document.querySelectorAll('[data-journal-entries] li').length>n,count);
 const stable=await p1.evaluate(()=>window.stage4dPanel===document.getElementById('battle-journal'));
 const scrollTop=await sc.evaluate(e=>e.scrollTop);if(!stable||scrollTop>2)throw Error('panel replaced or scroll reset '+scrollTop);
 const beforeDisconnect=await p1.locator('[data-journal-entries] li').count();await ctx1.setOffline(true);await runTurns(2);await ctx1.setOffline(false);
 await p1.waitForFunction(n=>document.querySelectorAll('[data-journal-entries] li').length>n,beforeDisconnect);
 const seq=await p1.locator('[data-journal-entries] li').evaluateAll(es=>es.map(e=>e.dataset.eventSeq));if(new Set(seq).size!==seq.length)throw Error('duplicates after reconnect');
 await p1.screenshot({path:path.join(lab,'ui-host.png'),fullPage:true});await p2.screenshot({path:path.join(lab,'ui-player.png'),fullPage:true});
 await p1.locator('[data-action="battle-log"]').click();if(!await p1.locator('#battle-journal').evaluate(e=>e.hidden))throw Error('toggle did not close');await p1.locator('[data-action="battle-log"]').click();
 if(nav!==0||errors.length)throw Error('reload/errors '+JSON.stringify({nav,errors}));
 fs.writeFileSync(path.join(lab,'ui-summary.json'),JSON.stringify({status:'PASS',independent_sessions:2,live_entries:seq.length,panel_preserved:stable,scrollTop,duplicates:0,reconnect:'cursor resumed',reloads:nav,errors},null,2));await browser.close();
})().catch(e=>{console.error(e);process.exit(1)});
