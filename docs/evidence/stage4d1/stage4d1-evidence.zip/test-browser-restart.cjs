const {chromium}=require('C:/Users/mi/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright');
const fs=require('fs'),path=require('path'),cp=require('child_process');
(async()=>{
const base='http://127.0.0.1:33494',lab=__dirname,game=JSON.parse(fs.readFileSync(path.join(lab,'fixtures.json'))).journal;
const file=path.join(lab,'private-access','restart-invitation.json');
cp.execFileSync('C:/OSPanel/modules/php/PHP_8.1/php.exe',[path.join(lab,'app/tools/journal_access.php'),'issue',String(game),'host','600',file],{env:{...process.env,PHPRC:'C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'}});
const invite=JSON.parse(fs.readFileSync(file));fs.unlinkSync(file);
const launch=()=>chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
let browser=await launch(),context=await browser.newContext(),page=await context.newPage();
await page.goto(base+'/journal-access.php');await page.locator('[name="invitation"]').fill(invite.secret);await page.locator('[type="submit"]').click();await page.waitForURL(/index.php/);
if((await context.request.get(base+'/battle-journal.php?game='+game)).status()!==200)throw Error('first access');
await browser.close();browser=await launch();context=await browser.newContext();page=await context.newPage();
if((await context.request.get(base+'/battle-journal.php?game='+game)).status()!==403)throw Error('restart gained access');
await page.goto(base+'/journal-access.php');await page.locator('[name="invitation"]').fill(invite.secret);const response=page.waitForResponse(r=>r.url().endsWith('/journal-access.php')&&r.request().method()==='POST');await page.locator('[type="submit"]').click();if((await response).status()!==403)throw Error('invitation replay');
await browser.close();fs.writeFileSync(path.join(lab,'browser-restart-summary.json'),JSON.stringify({status:'PASS',fresh_browser_without_cookie:403,spent_invitation:403}));
})().catch(e=>{console.error(e);process.exit(1)});
