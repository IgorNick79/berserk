<?php
require __DIR__.'/app/src/Core/Autoloader.php';Berserk\Core\Autoloader::register();Berserk\Core\Autoloader::addNamespace('Berserk\\',__DIR__.'/app/src/');
$db=new Berserk\Core\Db(require __DIR__.'/app/config/db.php');if($db->fetchOne('SELECT DATABASE() db')['db']!=='berserk_stage4d1_run1')throw new RuntimeException('Fixture DB only');$g=(int)($argv[1]??0);
if(($argv[2]??'')==='hide'||($argv[2]??'')==='reveal'){
 $row=$db->fetchOne("SELECT json FROM games WHERE ind=$g");$s=json_decode($row['json'],true);foreach($s['cards']as&$c)if($c['instance_id']==3){$c['revealed']=$argv[2]==='reveal';$c['move']=1;}
 $db->query("UPDATE games SET json='".$db->escape(json_encode($s,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))."' WHERE ind=$g");exit;
}
if(($argv[2]??'')==='events'){echo json_encode($db->fetchAll("SELECT * FROM battle_history_events WHERE game_id=$g ORDER BY event_seq"));exit;}
if(($argv[2]??'')==='block'){$max=(int)$db->fetchOne("SELECT last_event_seq FROM battle_history_matches WHERE game_id=$g")['last_event_seq'];$db->query("ALTER TABLE battle_history_events ADD CONSTRAINT stage4d_fault CHECK (game_id<>$g OR event_seq<=$max)");exit;}
if(($argv[2]??'')==='unblock'){$db->query('ALTER TABLE battle_history_events DROP CONSTRAINT stage4d_fault');exit;}
if(($argv[2]??'')==='state'){echo json_encode($db->fetchOne("SELECT * FROM games WHERE ind=$g"));exit;}
if(($argv[2]??'')==='steps'){echo json_encode($db->fetchAll("SELECT * FROM battle_history_steps WHERE game_id=$g ORDER BY step_seq"));exit;}
if(($argv[2]??'')==='tamper'){$db->query("UPDATE battle_history_steps SET state_hash=REPEAT('0',64) WHERE game_id=$g AND step_seq=1");exit;}
$out=[];foreach(['games','battle_command_journal','battle_history_matches','battle_history_batches','battle_history_actions','battle_history_events','battle_history_steps']as$t)$out[$t]=$db->fetchAll("SELECT * FROM $t".($t==='games'?" WHERE ind=$g":" WHERE game_id=$g"));echo json_encode($out);
