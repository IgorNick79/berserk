<?php
$p=__DIR__.'/app/config/battle_history.local.php';$c=require $p;
$c['journal_access_enabled']=true;$c['journal_access_directory']=__DIR__.'/private-access';$c['journal_access_local_http']=true;$c['journal_test_bindings']=[];
$c['journal_game_ids']=array_values(array_diff($c['journal_game_ids'],[40000008]));
file_put_contents($p,'<?php return '.var_export($c,true).';');
