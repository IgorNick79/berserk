import pathlib,subprocess,json,os,re,urllib.request,urllib.parse,http.cookiejar,urllib.error
lab=pathlib.Path(__file__).parent
base='http://127.0.0.1:33494'
php='C:/OSPanel/modules/php/PHP_8.1/php.exe'
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
ids=json.loads((lab/'fixtures.json').read_text())
def issue(game,side,ttl=3600):
 p=lab/'private-access'/('invitation-'+os.urandom(8).hex()+'.json')
 subprocess.run([php,str(lab/'app/tools/journal_access.php'),'issue',str(game),side,str(ttl),str(p.resolve())],capture_output=True,check=True)
 value=json.loads(p.read_text());p.unlink();return value

def new_client():return urllib.request.build_opener(urllib.request.ProxyHandler({}),urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
def req(c,path,data=None):
 try:
  with c.open(base+path,None if data is None else urllib.parse.urlencode(data).encode()) as r:return r.status,r.read().decode('utf-8-sig')
 except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8-sig')
def redeem(c,secret):
 code,body=req(c,'/journal-access.php');assert code==200
 csrf=re.search(r'name="csrf" value="([a-f0-9]+)"',body)[1]
 return req(c,'/journal-access.php',dict(csrf=csrf,invitation=secret))
def client(identity):
 c=new_client()
 if ':' in identity:
  name,side=identity.split(':');game=ids[name]
  if name!='disabled':
   grant=issue(game,side);code,body=redeem(c,grant['secret']);assert code==200,(code,body[:100])
 req(c,'/lab-dice.php');return c
