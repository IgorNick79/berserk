import urllib.request,urllib.parse,urllib.error,http.cookiejar,json,subprocess,os,re,pathlib,traceback
lab=pathlib.Path(__file__).parent; base='http://127.0.0.1:33494'; php='C:/OSPanel/modules/php/PHP_8.1/php.exe'
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
ids=json.loads((lab/'fixtures.json').read_text()); results=[]
def db(g,kind='all'):
 p=subprocess.run([php,str(lab/'inspect.php'),str(g),kind],capture_output=True,text=True,encoding='utf-8-sig',check=True)
 return json.loads(p.stdout) if p.stdout.strip() else None
from auth import client

def request(c,path,data=None):
 try:
  with c.open(base+path,None if data is None else urllib.parse.urlencode(data).encode())as r:return r.status,r.read().decode('utf-8-sig')
 except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8-sig')
cs={};clients={}
def select(name):
 global cs
 cs={1:clients.setdefault(name+':host',client(name+':host')),2:clients.setdefault(name+':player',client(name+':player')),0:client('legacy')}

def test(name,fn):
 try: detail=fn();results.append(dict(name=name,status='PASS',detail=detail));print('PASS',name,flush=True)
 except Exception as e:results.append(dict(name=name,status='FAIL',error=str(e)));print('FAIL',name,str(e),flush=True);traceback.print_exc()
def check(b,msg):
 if not b:raise AssertionError(msg)
def prep(g,u,cmd='confirm_place',**payload):
 role='first'if u==1 else'second';code,html=request(cs[u],f'/index.php?{role}&game={g}');check(code==200,'prep page '+str(code)+html[:200]);
 token=re.search(r'prepare_token=([a-f0-9]+)',html);check(token,'prep token absent '+html[:200]);v=db(g,'state')['version']
 q=dict(game=g,cmd=cmd,prepare_version=v,prepare_token=token[1],**payload);return request(cs[u],'/index.php?'+role+'&'+urllib.parse.urlencode(q))
def start(g):
 for u in [1,2]:
  code,html=prep(g,u);check(code==200,'confirm HTTP '+str(code)+html[:300])
 check(db(g,'state')['status']=='battle','battle start');return db(g,'steps')
def command(g,u,typ,**payload):
 role='first'if u==1 else'second';v=db(g,'state')['version'];data=dict(cmd=typ,expected_version=v,command_id='c4c:'+os.urandom(10).hex(),**payload)
 code,body=request(cs[u],f'/index.php?{role}&game={g}&ajax=battle_command',data);check(code==200,f'{typ} HTTP {code} {body[:500]}');j=json.loads(body);check(j.get('ok'),f'{typ} {j.get("error")} {j.get("message")} {str(j)[-500:]}');return j
def state(g):return json.loads(db(g,'state')['json'])
def combat(g,target=2):command(g,1,'strike',card_id=1,target_id=target);finish(g)
def finish(g):
 for _ in range(12):
  s=state(g);x=s.get('battle',{}).get('strike');
  if s['status']=='game_over'or not x:return
  mode=x['state']
  if mode=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
  elif mode=='waiting_choice':command(g,1 if x['choice_winner']=='attack'else 2,'choose_strike_mode',mode='normal')
  elif mode=='results':
   # token comes from persisted informational_wait DTO
   for u,key in [(1,'host'),(2,'player')]:
    s=state(g);x=s['battle'].get('strike');
    if not x:break
    if key not in x.get('confirmed',[]):
     wait=s['battle'].get('informational_wait',{});command(g,u,'confirm_strike',wait_id=wait.get('wait_id',wait.get('id',0)))
  else:raise AssertionError('wait '+mode)
 raise AssertionError('combat unfinished')
def api(g,kind='metadata',step=None,user=1):
 return request(cs[user],'/replay.php?'+urllib.parse.urlencode(dict(game=g,api=kind,**({'step':step}if step else{}))))

def journal(g,u=1,after=0,limit=100,extra=''):
 code,body=request(cs[u],f'/battle-journal.php?game={g}&after={after}&limit={limit}'+extra)
 return code,json.loads(body)
def entries(g,u=1):
 out=[];cursor=0
 for _ in range(100):
  code,data=journal(g,u,cursor,3);check(code==200,'journal '+str(data));out+=data['entries'];check(data['cursor']>=cursor,'cursor back');cursor=data['cursor']
  if not data['has_more']:return out,cursor,data
 raise AssertionError('pagination infinite')
def normal():
 select('journal');g=ids['journal'];start(g);command(g,1,'move',card_id=3,row=2,col=3);combat(g);command(g,1,'end_turn');command(g,2,'resign')
 events=db(g,'events');types=[e['event_type']for e in events]
 for typ in ['move.started','combat.started','combat.dice','combat.result','combat.wounds','turn.ended','turn.started','match_terminal.settled']:check(typ in types,typ+' missing')
 for u in [1,2]:
  rows,c,data=entries(g,u);text=' '.join(x['text']for x in rows);check('атакует'in text and 'Бросок'in text and 'получает'in text,'visible combat missing');check('Бой завершён'in text,'terminal missing');check('ACK'not in text and 'command_id'not in text,'technical data')
  check(journal(g,u,c)[1]['entries']==[],'duplicate poll')
 (lab/'two-players.json').write_text(json.dumps({str(u):entries(g,u)for u in[1,2]},ensure_ascii=False,indent=2),encoding='utf-8')
 return types

def status():
 select('status');g=ids['status'];
 if db(g,'state')['status']=='place':start(g)
 command(g,1,'turn_sub',sub_id='instant_3_close')
 s=state(g)
 if s['battle'].get('pending_instant_pick'):command(g,1,'choose_instant_pick',target_id=2)
 command(g,1,'pass_turn_instant')
 rows=db(g,'events');status=[x for x in rows if x['event_type']=='card.status'];check(len(status)==1,'status event absent');check(json.loads(status[0]['payload_json'])['closed']==True,'status result');check(status[0]['player_json']is None,'private source effect leaked')
 ability=[x for x in rows if x['event_type']=='ability.applied'];check(len(ability)==1,'applied turn ability missing');before=db(g);result=entries(g)[0];check(db(g)==before,'pending/timer changed on journal read');return result
test('real turn instant status and applied ability are recorded privately',status)
(lab/'status-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');raise SystemExit(any(x['status']=='FAIL'for x in results))
