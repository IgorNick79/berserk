USE berserk_stage4b_regression;
CREATE TABLE elements(ind INT PRIMARY KEY,code VARCHAR(32),name VARCHAR(128)) ENGINE=InnoDB;
INSERT INTO elements VALUES(1,'neutral','Synthetic neutral');
CREATE TABLE cards(ind INT PRIMARY KEY,ukid VARCHAR(64),name VARCHAR(128),health INT,move INT,strike_weak INT,strike_medium INT,strike_strong INT,prop LONGTEXT,price INT DEFAULT 1,elite INT DEFAULT 0,single INT DEFAULT 0,element_id INT DEFAULT 1,descr TEXT,rarity VARCHAR(16) DEFAULT '',class VARCHAR(128) DEFAULT '',type VARCHAR(16) DEFAULT 'creature') ENGINE=InnoDB;
INSERT INTO cards(ind,ukid,name,health,move,strike_weak,strike_medium,strike_strong,prop,descr) VALUES(1,'stage3_a','Synthetic A',20,2,1,2,3,'{}',''),(2,'stage3_b','Synthetic B',20,2,1,2,3,'{}','');

CREATE TABLE games (ind INT AUTO_INCREMENT PRIMARY KEY,host_id INT NOT NULL,player_id INT NOT NULL,status VARCHAR(32),json LONGTEXT,version INT NOT NULL DEFAULT 0,date DATETIME,active INT) ENGINE=InnoDB;
