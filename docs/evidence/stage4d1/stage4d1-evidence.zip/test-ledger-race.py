from auth import *
grant=issue(ids['journal'],'host');p=lab/'private-access/race-input.json';p.write_text(json.dumps(grant))
try:
 workers=[subprocess.Popen([php,str(lab/'consume-worker.php'),str(p.resolve())],stdout=subprocess.PIPE,stderr=subprocess.PIPE) for _ in range(2)]
 codes=[]
 for worker in workers:
  out,err=worker.communicate();assert not err,err;codes.append(worker.returncode)
 assert sorted(codes)==[0,2],codes
 (lab/'ledger-race-summary.json').write_text(json.dumps(dict(status='PASS',separate_php_processes=2,successful_consumptions=1)))
 print('PASS separate PHP processes: one invitation consumed exactly once')
finally:p.unlink()
