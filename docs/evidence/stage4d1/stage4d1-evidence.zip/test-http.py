import urllib.request,urllib.parse,urllib.error,http.cookiejar,json,subprocess,os,re,pathlib,traceback
lab=pathlib.Path(__file__).parent; base='http://127.0.0.1:33494'; php='C:/OSPanel/modules/php/PHP_8.1/php.exe'
os.environ['PHPRC']='C:/Users/mi/Documents/Berserk/stage4b-verification/php.ini'
ids=json.loads((lab/'fixtures.json').read_text()); results=[]
def db(g,kind='all'):
 p=subprocess.run([php,str(lab/'inspect.php'),str(g),kind],capture_output=True,text=True,encoding='utf-8-sig',check=True)
 return json.loads(p.stdout) if p.stdout.strip() else None
from auth import client

def request(c,path,data=None):
 try:
  with c.open(base+path,None if data is None else urllib.parse.urlencode(data).encode())as r:return r.status,r.read().decode('utf-8-sig')
 except urllib.error.HTTPError as e:return e.code,e.read().decode('utf-8-sig')
cs={};clients={}
def select(name):
 global cs
 cs={1:clients.setdefault(name+':host',client(name+':host')),2:clients.setdefault(name+':player',client(name+':player')),0:client('legacy')}

def test(name,fn):
 try: detail=fn();results.append(dict(name=name,status='PASS',detail=detail));print('PASS',name,flush=True)
 except Exception as e:results.append(dict(name=name,status='FAIL',error=str(e)));print('FAIL',name,str(e),flush=True);traceback.print_exc()
def check(b,msg):
 if not b:raise AssertionError(msg)
def prep(g,u,cmd='confirm_place',**payload):
 role='first'if u==1 else'second';code,html=request(cs[u],f'/index.php?{role}&game={g}');check(code==200,'prep page '+str(code)+html[:200]);
 token=re.search(r'prepare_token=([a-f0-9]+)',html);check(token,'prep token absent '+html[:200]);v=db(g,'state')['version']
 q=dict(game=g,cmd=cmd,prepare_version=v,prepare_token=token[1],**payload);return request(cs[u],'/index.php?'+role+'&'+urllib.parse.urlencode(q))
def start(g):
 for u in [1,2]:
  code,html=prep(g,u);check(code==200,'confirm HTTP '+str(code)+html[:300])
 check(db(g,'state')['status']=='battle','battle start');return db(g,'steps')
def command(g,u,typ,**payload):
 role='first'if u==1 else'second';v=db(g,'state')['version'];data=dict(cmd=typ,expected_version=v,command_id='c4c:'+os.urandom(10).hex(),**payload)
 code,body=request(cs[u],f'/index.php?{role}&game={g}&ajax=battle_command',data);check(code==200,f'{typ} HTTP {code} {body[:500]}');j=json.loads(body);check(j.get('ok'),f'{typ} {j.get("error")} {j.get("message")} {str(j)[-500:]}');return j
def state(g):return json.loads(db(g,'state')['json'])
def combat(g,target=2):command(g,1,'strike',card_id=1,target_id=target);finish(g)
def finish(g):
 for _ in range(12):
  s=state(g);x=s.get('battle',{}).get('strike');
  if s['status']=='game_over'or not x:return
  mode=x['state']
  if mode=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
  elif mode=='waiting_choice':command(g,1 if x['choice_winner']=='attack'else 2,'choose_strike_mode',mode='normal')
  elif mode=='results':
   # token comes from persisted informational_wait DTO
   for u,key in [(1,'host'),(2,'player')]:
    s=state(g);x=s['battle'].get('strike');
    if not x:break
    if key not in x.get('confirmed',[]):
     wait=s['battle'].get('informational_wait',{});command(g,u,'confirm_strike',wait_id=wait.get('wait_id',wait.get('id',0)))
  else:raise AssertionError('wait '+mode)
 raise AssertionError('combat unfinished')
def api(g,kind='metadata',step=None,user=1):
 return request(cs[user],'/replay.php?'+urllib.parse.urlencode(dict(game=g,api=kind,**({'step':step}if step else{}))))

def journal(g,u=1,after=0,limit=100,extra=''):
 code,body=request(cs[u],f'/battle-journal.php?game={g}&after={after}&limit={limit}'+extra)
 return code,json.loads(body)
def entries(g,u=1):
 out=[];cursor=0
 for _ in range(100):
  code,data=journal(g,u,cursor,3);check(code==200,'journal '+str(data));out+=data['entries'];check(data['cursor']>=cursor,'cursor back');cursor=data['cursor']
  if not data['has_more']:return out,cursor,data
 raise AssertionError('pagination infinite')
def normal():
 select('journal');g=ids['journal'];start(g);command(g,1,'move',card_id=3,row=2,col=3);combat(g);command(g,1,'end_turn');command(g,2,'resign')
 events=db(g,'events');types=[e['event_type']for e in events]
 for typ in ['move.started','combat.started','combat.dice','combat.result','combat.wounds','turn.ended','turn.started','match_terminal.settled']:check(typ in types,typ+' missing')
 for u in [1,2]:
  rows,c,data=entries(g,u);text=' '.join(x['text']for x in rows);check('атакует'in text and 'Бросок'in text and 'получает'in text,'visible combat missing');check('Бой завершён'in text,'terminal missing');check('ACK'not in text and 'command_id'not in text,'technical data')
  check(journal(g,u,c)[1]['entries']==[],'duplicate poll')
 (lab/'two-players.json').write_text(json.dumps({str(u):entries(g,u)for u in[1,2]},ensure_ascii=False,indent=2),encoding='utf-8')
 return types
test('real HTTP movement strike dice wounds turn terminal for two bound sessions',normal)
def hidden():
 select('hidden');g=ids['hidden'];start(g);db(g,'hide');command(g,1,'move',card_id=3,row=2,col=3);first=db(g,'events');moves=[x for x in first if x['event_type']=='move.started'];check(len(moves)==1,'movement event missing');old=moves[0]
 check(old['player_json']is None and old['host_json']is not None,'historical visibility');host=entries(g,1)[0];opp=entries(g,2)[0];check(any('перемещается'in x['text']for x in host),'owner missing');check(not any('перемещается'in x['text']for x in opp),'hidden identity leak')
 db(g,'reveal');command(g,1,'move',card_id=3,row=2,col=4);check(any('перемещается'in x['text']for x in entries(g,2)[0]),'later reveal not logged');check(db(g,'events')[first.index(old)]==old,'old projection changed');return dict(host=host,player=opp,old_event=old)
test('hidden card owner-only projection and immutable old event after reveal',hidden)
def instant():
 select('instant');g=ids['instant'];start(g);command(g,1,'strike',card_id=1,target_id=2)
 played=False
 for i in range(18):
  st=state(g);x=st['battle'].get('strike')
  if not x:break
  if x['state']=='waiting_defender':command(g,2,'choose_defender',defender_id=0)
  elif x['state']=='waiting_instant':
   u=1 if x['instant_priority']=='host'else 2
   if not played and u==1 and x.get('combat_instant_window')=='main':command(g,1,'combat_instant_play',card_id=3,instant_key='reduce');played=True
   else:command(g,u,'combat_instant_pass')
  elif x['state']=='waiting_choice':command(g,1 if x['choice_winner']=='attack'else 2,'choose_strike_mode',mode='normal')
  elif x['state']=='results':finish(g);break
  else:raise AssertionError('instant wait '+str(x))
 check(played,'instant not played');check(state(g)['cards']['2']['hp']==17 if isinstance(state(g)['cards'],dict)else True,'damage not reduced')
 ev=db(g,'events');result=[json.loads(x['payload_json'])for x in ev if x['event_type']=='combat.result'];check(len(result)==1 and result[0]['attack']=='medium','final result not reduced');check(len([x for x in ev if x['event_type']=='combat.dice'])==1,'dice repeated');check(len([x for x in ev if x['event_type']=='combat.wounds'])==1,'damage repeated');ability=[x for x in ev if x['event_type']=='ability.applied'];check(len(ability)==1,'ability missing or repeated')
 a=entries(g,1)[0];b=entries(g,2)[0];check(any('Тайное ослабление'in x['text']for x in a),'owner ability missing');check(not any('Тайное ослабление'in x['text']for x in b),'private ability leaked');check(any('средний удар'in x['text']for x in b),'final visible result missing');check(entries(g)[2]['recording']['has_gaps'],'gap not exposed')
 roots=[x['action_id']for x in ev if x['event_type']in['combat.started','combat.dice','combat.result','combat.wounds','ability.applied']];check(len(set(roots))==1,'combat cause lost across commands');return dict(events=ev,host=a,player=b)
test('actual HTTP instant changes final result; no dice/wounds duplicates; root preserved',instant)
def heal():
 select('heal');g=ids['heal'];start(g);command(g,1,'action',card_id=1,target_id=3,action_key='heal');ev=db(g,'events');hp=[json.loads(x['payload_json'])for x in ev if x['event_type']=='card.healed'];check(len(hp)==1 and hp[0]['amount']==2,'actual clamped heal missing');a=entries(g,1)[0];check(any('восстанавливает 2 HP'in x['text']for x in a),'heal UItext');return a
test('actual HTTP active heal logs real clamped HP delta',heal)
def lethal():
 select('lethal');g=ids['lethal'];start(g);combat(g);check('combat.death'in[x['event_type']for x in db(g,'events')],'death event');check(any('погибает'in x['text']for x in entries(g)[0]),'death text');return entries(g)[0]
test('actual HTTP death and terminal',lethal)
def access():
 select('journal');g=ids['journal'];check(journal(g,0)[0]==403,'legacy session accepted');check(journal(g,1,extra='&side=player')[0]==400,'side spoof accepted');check(journal(ids['hidden'],1)[0]==403,'foreign match accepted');code,body=request(cs[1],f'/replay.php?game={g}');check(code==401,'Stage4C trust weakened');return 'legacy role/session, side spoof, foreign match rejected; replay remains protected'
test('server binding rejects legacy, foreign match and side substitution',access)
def read_only():
 select('hidden');g=ids['hidden'];before=db(g)
 for _ in range(3):entries(g,1);entries(g,2)
 check(db(g)==before,'journal read changed SQL state');config=lab/'app/config/db.php';old=config.read_text();config.write_text(old.replace("'user'=>'stage4b'","'user'=>'stage4c_read'").replace("'pass'=>'stage4b_test_only'","'pass'=>'stage4c_read_only'"))
 try:check(journal(g)[0]==200,'SELECT-only reader fails')
 finally:config.write_text(old)
 originals={}
 try:
  for f in ['Core/Engine.php','Core/GameRepository.php','Core/AutomaticBattleProgress.php','Core/HttpBattleProgress.php']:
   p=lab/'app/src'/f;originals[p]=p.read_bytes();s=p.read_text(encoding='utf-8');pos=s.index(';',s.index('namespace Berserk'))+1;p.write_text(s[:pos]+" throw new \\RuntimeException('journal must not load gameplay');"+s[pos:],encoding='utf-8')
  check(journal(g)[0]==200,'gameplay loaded by reader')
 finally:
  for p,s in originals.items():p.write_bytes(s)
 return 'SQL games/json/version/timers/pending/journal/history unchanged; SELECT-only and throw-on-load traps passed'
test('journal is read-only and isolated from gameplay',read_only)
def retry():
 select('rollback');g=ids['rollback'];start(g);v=db(g,'state')['version'];q=dict(cmd='move',card_id=3,row=2,col=3,expected_version=v,command_id='stage4d-retry')
 code,body=request(cs[1],f'/index.php?first&game={g}&ajax=battle_command',q);check(code==200 and json.loads(body)['ok'],'first move');before=db(g,'events');code,body=request(cs[1],f'/index.php?first&game={g}&ajax=battle_command',q);check(code==200 and json.loads(body)['ok'],'retry');check(db(g,'events')==before,'retry produced events');return 'committed command retry returns same history'
test('committed retry creates no duplicate journal events',retry)
def rollback():
 g=ids['rollback'];before=db(g);db(g,'block')
 try:
  v=db(g,'state')['version'];code,body=request(cs[1],f'/index.php?first&game={g}&ajax=battle_command',dict(cmd='move',card_id=1,row=3,col=2,expected_version=v,command_id='stage4d-fault'));check(code>=400 or not json.loads(body).get('ok'),'SQL failure success')
 finally:db(g,'unblock')
 after=db(g);check(after['games']==before['games'],'failed event changed game');
 for t in ['battle_history_matches','battle_history_batches','battle_history_actions','battle_history_events','battle_history_steps']:check(after[t]==before[t],'rollback '+t)
 return 'failed mandatory event insertion rolled game and entire history back'
test('event SQL failure rolls back game actions events and snapshots',rollback)
def disabled():
 select('disabled');g=ids['disabled']
 for role in ['first','second']:
  code,body=request(cs[0],f'/index.php?{role}&game={g}&cmd=confirm_place');check(code==200,'disabled prep')
 command(g,1,'move',card_id=3,row=2,col=3);check(db(g,'events')==[],'Recorder enabled on unlisted match');check(journal(g)[0]==404,'ordinary journal exposed');return 'normal unrecorded game unchanged; empty history distinguished'
test('Recorder OFF leaves normal game behavior unchanged',disabled)
(lab/'http-summary.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');raise SystemExit(any(x['status']=='FAIL'for x in results))
